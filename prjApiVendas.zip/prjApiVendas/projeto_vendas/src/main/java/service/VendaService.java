package main.java.service;

import model.Produto;
import model.Venda;
import repository.ProdutoRepository;
import repository.VendaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class VendaService {
    @Autowired
    private VendaRepository vendaRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    public boolean realizarVenda(Venda venda) {
        Produto produto = produtoRepository.findById(venda.getIdProduto()).orElse(null);
        if (produto != null && produto.getEstoque() >= venda.getQuantidade() && venda.getQuantidade() > 0) {
            produto.setEstoque(produto.getEstoque() - venda.getQuantidade());
            produtoRepository.save(produto);

            venda.setData(new Date());
            vendaRepository.save(venda);
            return true;
        }
        return false;
    }

    public List<Venda> listarVendas() {
        return vendaRepository.findAll();
    }

}
