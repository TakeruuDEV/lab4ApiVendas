package main.java.controller;

import model.Venda;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import service.VendaService;

import java.util.List;

@RestController
@RequestMapping("/vendas")
public class VendaController {
    @Autowired
    private VendaService vendaService;

    @PostMapping
    public ResponseEntity<String> realizarVenda(@RequestBody Venda venda) {
        boolean vendaRealizada = vendaService.realizarVenda(venda);
        if (vendaRealizada) {
            return new ResponseEntity<>("Venda realizada com sucesso!", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Não foi possível realizar a venda. Verifique os dados e tente novamente.", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping
    public ResponseEntity<List<Venda>> historicoVendas() {
        List<Venda> vendas = vendaService.listarVendas();
        return new ResponseEntity<>(vendas, HttpStatus.OK);
    }

}
