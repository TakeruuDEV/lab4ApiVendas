INSERT INTO Produto (nome, preco, estoque) VALUES ('Produto A', 100.0, 50);
INSERT INTO Produto (nome, preco, estoque) VALUES ('Produto B', 200.0, 30);
INSERT INTO Produto (nome, preco, estoque) VALUES ('Produto C', 300.0, 20);